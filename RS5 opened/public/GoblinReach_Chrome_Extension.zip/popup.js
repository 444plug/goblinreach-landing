
document.getElementById('start').addEventListener('click', function () {
    const username = document.getElementById('username').value;
    const delay = parseInt(document.getElementById('delay').value, 10);
    chrome.runtime.sendMessage({ start: true, username, delay });
});
