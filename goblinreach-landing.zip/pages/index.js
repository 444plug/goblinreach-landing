
export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gray-50 px-4">
      <h1 className="text-5xl font-extrabold mb-4 text-center">GoblinReach</h1>
      <p className="text-xl mb-8 text-gray-700 text-center max-w-xl">
        Dominate Instagram DMs with AI-powered automation. Grow faster, close more, and turn followers into cash.
      </p>
      <a
        href="#"
        className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
      >
        Start Your Free Trial
      </a>
    </main>
  )
}
