
chrome.runtime.onMessage.addListener(function (req, sender, sendResponse) {
    if (req.start) {
        console.log("Starting DM bot for", req.username);
        // Placeholder logic for actual DM bot connection
    }
});
